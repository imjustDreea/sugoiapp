import './index.css'
import './App.css'
import Dashboard from './pages/Dashboard'

export function App() {

  return (
    <Dashboard />
  )
}
